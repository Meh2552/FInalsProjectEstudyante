package package1;

import java.util.*;

public class UserManager extends DocuHandler 
{

    @Override
    public String getFileName() 
    {
        return "users.txt";
    }

    public UserManager() 
    {
        super();
    }

    public void addUser(UserRecord record) 
    {
        append(record.toFileLine());
    }

    public boolean usernameExists(String username)
    {
        List<String> lines = read();
        
        for (String line : lines) 
        {
            String[] part = line.split(",");
            if (part.length > 0 && part[0].equalsIgnoreCase(username))
            {
            	return true;
            }
        }
        return false;
    }

    public boolean studentNumExists(String stNum) 
    {
        List<String> lines = read();
        
        for (String line : lines) 
        {
            String[] part = line.split(",");
            
            if (part.length == 5) 
            {
                if (part[3].equals(stNum))
                {
                	return true;
                }
            }
        }
        
        return false;
    }

    public String readUserLine(String username)
    {
        List<String> lines = read();
        
        for (String line : lines) 
        {
            String[] part = line.split(",");
            if (part.length > 0 && part[0].equalsIgnoreCase(username))
            {
            	return line;
            }
        }
        return null;
    }

    public String studentNumGenerate() {

        int randomNum = (int) (Math.random() * 1000001);
        String generated = String.format("%s"+ "%06d","02000-", randomNum);

        return generated;
        
    }

    public UserRecord verify(String username, String password) 
    {
        List<String> lines = read();
        
        for (String line : lines) 
        {
            String[] part = line.split(",");
            
            if (part.length == 5) // student ito
            {
                if (part[0].equalsIgnoreCase(username) && part[1].equals(password)) 
                {
                    return new UserRecord(part[0], part[1], part[3], part[4]);
                }
            } 
            
            else if (part.length == 4) // employee ito
            { 
                if (part[0].equalsIgnoreCase(username) && part[1].equals(password)) 
                {
                    UserRecord.Role role = UserRecord.Role.valueOf(part[2]);
                    
                    return new UserRecord(part[0], part[1], role, part[3]);
                }
            }
        }
        return null;
    }

    public void deleteUser(String username) 
    {
        List<String> lines = read();
        
        ArrayList<String> out = new ArrayList<String>();
        
        for (String line : lines) 
        {
            String[] part = line.split(",");
            
            if (part.length > 0 && part[0].equalsIgnoreCase(username)) 
            {
                continue; 
            }
            out.add(line);
        }
        write(out);
    }

    public void changeUser(String username, String newUsername) {
        List<String> lines = read();

        ArrayList<String> out = new ArrayList<String>();

        for (String line : lines) {
            String[] part = line.split(",");

            if (part.length > 0 && part[0].equalsIgnoreCase(username)) {
                String output = "";
                boolean first = true;

  
                for (String text : part) {
                    if (first) {
                        first = false;
                        text = newUsername;
                        output = output.concat(text);
                        continue;
                    }

                    output = output.concat("," + text);
                }

                out.add(output);
                continue;
            }

            out.add(line);
        }
        write(out);
    }

    public void changePass(String username, String newPassword) {
        List<String> lines = read();

        ArrayList<String> out = new ArrayList<String>();

        for (String line : lines) {
            String[] part = line.split(",");

            if (part.length > 0 && part[0].equalsIgnoreCase(username)) {
                String output = "";
                int count = 0;


                for (String text : part) {
                    count++;

                    if (count != 1) output = output.concat(",");
                    if (count == 2) text = newPassword;

                    output = output.concat(text);
                }

                out.add(output);
                continue;
            }

            out.add(line);
        }
        write(out);
    }

    public List<UserRecord> loadAll() 
    {
        List<String> lines = read();
        
        ArrayList<UserRecord> list = new ArrayList<UserRecord>();
        
        for (String line : lines) 
        {
            String[] part = line.split(",");
            
            if (part.length == 5) 
            {
                list.add(new UserRecord(part[0], part[1], part[3], part[4]));
            } 
            
            else if (part.length == 4) 
            {
                UserRecord.Role role = UserRecord.Role.valueOf(part[2]);
                
                list.add(new UserRecord(part[0], part[1], role, part[3]));
            }
        }
        return list;
    }
}