package package1;

public interface HelpdeskResponder 
{
	void respondToTicket();
	    
}
